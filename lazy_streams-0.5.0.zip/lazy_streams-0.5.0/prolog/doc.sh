swipl -s lazy_streams.pl -g "doc_save(., [recursive(true)]),halt"
open doc/index.html
