swipl -g "use_module(lazy_streams)"
