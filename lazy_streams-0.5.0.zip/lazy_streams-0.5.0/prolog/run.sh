swipl --stack_limit=8G -g "use_module(lazy_streams)"
