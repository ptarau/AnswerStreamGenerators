swipl -s test_lazy_streams.pl
