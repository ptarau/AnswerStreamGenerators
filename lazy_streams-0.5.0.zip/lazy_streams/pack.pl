name(lazy_streams).
title('Lazy Stream Generators').

version('0.5.0').
download('https://github.com/ptarau/AnswerStreamGenerators/lazy_lists.zip').

% requires(nothing).

author('Paul Tarau','ptarau@gmail.com').
packager('Paul Tarau','ptarau@gmail.com').
maintainer('Paul Tarau','ptarau@gmail.com').
home('https://github.com/ptarau/AnswerStreamGenerators/lazy_lists/').
